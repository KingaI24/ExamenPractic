package Service;

import Domain.Pacient;
import Repository.IRepository;

import java.util.ArrayList;
import java.util.List;

public class ServicePacient {

    private IRepository<Pacient> repository;

    public ServicePacient(IRepository<Pacient> repository) {
        this.repository = repository;
    }

    public void addOrUpdate(int id, String CNP, String firstName, String lastName, String date, String regDate) {
        List <Pacient> CNPcheck= repository.show();
        for (Pacient c: CNPcheck) {
            if (c.getCNP().equals(CNP)) {
                throw new ServiceException("error: existent CNP");
            }
        }

        Pacient pp = new Pacient(id, CNP, firstName, lastName, date, regDate);
        repository.add(pp);
    }

    public void remove (int id) {
        repository.remove(id);
    }

    public List<Pacient> showPacients() {
        return repository.show();
    }

    public List<Pacient> fullTextSearch(String text) {
        List<Pacient> list = new ArrayList<>();
        for (Pacient pacient : repository.show()) {
            if (pacient.toString().toLowerCase().contains(text.toLowerCase()))
                list.add(pacient);
        }
        return list;
    }
}
